package com.example.appbbddexamen

data class Cliente (
    val id : Int,
    val nombre : String,
    val apellidos : String,
    val numCuenta : String,
    val dinero : Double
)